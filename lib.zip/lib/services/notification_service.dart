import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  debugPrint("Handling background message: ${message.messageId}");
}

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  Future<void> initialize() async {
    NotificationSettings settings = await _firebaseMessaging.requestPermission(
      alert: true,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      debugPrint("User authorized");
    }

    // FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    // const AndroidInitializationSettings androidSettings =
    //     AndroidInitializationSettings('@mipmap/ic_launcher');

    // const DarwinInitializationSettings iosSettings =
    //     DarwinInitializationSettings();

    // const InitializationSettings initializationSettings =
    //     InitializationSettings(android: androidSettings, iOS: iosSettings);

    // await _localNotifications.initialize(
    //   initializationSettings,

    //   onDidReceiveNotificationResponse:
    //       (NotificationResponse notificationResponse) {
    //         debugPrint("Notification Resopnse $notificationResponse");
    //       },
    // );
  }

  Future<String?> getToken() async {
    return _firebaseMessaging.getToken();
  }
}
